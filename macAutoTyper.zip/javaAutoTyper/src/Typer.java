import java.awt.*;
import java.util.Scanner;
import java.awt.event.KeyEvent;
import java.awt.datatransfer.StringSelection;
import java.awt.datatransfer.Clipboard;
import java.awt.EventQueue;
import javax.swing.JFrame;
import javax.swing.JOptionPane;




public class Typer {

    public static void main(String[] args) throws AWTException, InterruptedException {
        Scanner scanner = new Scanner(System.in);
        System.out.println("Enter the text you would like to auto-type:");
        String text = scanner.nextLine();

        Thread.sleep(5000);//5 sec delay

        for (int i = 0; i < text.length(); i++) {
            char c = text.charAt(i);

            String charText = String.valueOf(c); //char c -> string 'text'


            StringSelection stringSelection = new StringSelection(charText);
            Clipboard clipboard = Toolkit.getDefaultToolkit().getSystemClipboard();
            clipboard.setContents(stringSelection, stringSelection);

            Robot robot = new Robot(); //import robot

            // Simulate copy and paste key presses

            robot.keyPress(KeyEvent.VK_META);
            Thread.sleep(30);
            robot.keyPress(KeyEvent.VK_V);
            robot.keyRelease(KeyEvent.VK_V);
            Thread.sleep(30);
            robot.keyRelease(KeyEvent.VK_META);
            Thread.sleep(30);



        }
        try {
            // sleep for a random amount of time between 0 and 200 milliseconds
            Thread.sleep((long)(Math.random() * 200));
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
    }
}

//Copyright Reid Sunshine 2022
//All rights reserved.