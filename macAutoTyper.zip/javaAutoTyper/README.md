# javaAutoTyper
a simple program made in Java to accept user string input, then types it slowly like a human.

-----

Make sure you tab into the text field you want to type in after entering your input.

For questions, suggestions, or inquires, email me at rsunshine35@gmail.com, or add me on Discord 'Reid#5410'

reidsunshine.com


Copyright Reid Sunshine 2022
All rights reserved.
